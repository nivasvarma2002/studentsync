package com.example.lost_and_found

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

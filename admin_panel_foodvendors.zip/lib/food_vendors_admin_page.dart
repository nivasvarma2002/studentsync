import 'package:flutter/material.dart';

class FoodVendorsAdminPage extends StatefulWidget {
  @override
  _FoodVendorsAdminPageState createState() => _FoodVendorsAdminPageState();
}

class _FoodVendorsAdminPageState extends State<FoodVendorsAdminPage> {
  // List to store vendor data
  final List<Map<String, dynamic>> vendors = [];

  // Controllers to handle form input
  final TextEditingController _restaurantNameController =
      TextEditingController();
  final TextEditingController _restaurantDescriptionController =
      TextEditingController();
  final TextEditingController _locationCityController = TextEditingController();
  final TextEditingController _locationProvinceController =
      TextEditingController();
  final TextEditingController _contactNameController = TextEditingController();
  final TextEditingController _contactEmailController = TextEditingController();
  final TextEditingController _menuDescriptionController =
      TextEditingController();
  final TextEditingController _foodNameController = TextEditingController();
  final TextEditingController _foodDescriptionController =
      TextEditingController();

  // Method to add new vendor
  void _addVendor() {
    final newVendor = {
      'restaurantName': _restaurantNameController.text,
      'restaurantDescription': _restaurantDescriptionController.text,
      'location': {
        'city': _locationCityController.text,
        'province': _locationProvinceController.text,
        // Add other location fields as needed
      },
      'contact': {
        'personName': _contactNameController.text,
        'Email': _contactEmailController.text,
        // Add other contact fields as needed
      },
      'menu': {
        'menuDescription': _menuDescriptionController.text,
        // Add other menu fields as needed
      },
      'foodItems': [
        {
          'foodName': _foodNameController.text,
          'foodDescription': _foodDescriptionController.text,
          // Add other food fields as needed
        }
      ],
    };

    setState(() {
      vendors.add(newVendor);
    });
    // Clear all text fields after adding vendor
    _restaurantNameController.clear();
    _restaurantDescriptionController.clear();
    _locationCityController.clear();
    _locationProvinceController.clear();
    _contactNameController.clear();
    _contactEmailController.clear();
    _menuDescriptionController.clear();
    _foodNameController.clear();
    _foodDescriptionController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Food Vendors Admin Page'),
      ),
      body: SingleChildScrollView(
        // Wrap the body with SingleChildScrollView
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  TextField(
                    controller: _restaurantNameController,
                    decoration: InputDecoration(labelText: 'Restaurant Name'),
                  ),
                  TextField(
                    controller: _restaurantDescriptionController,
                    decoration:
                        InputDecoration(labelText: 'Restaurant Description'),
                  ),
                  TextField(
                    controller: _locationCityController,
                    decoration: InputDecoration(labelText: 'City'),
                  ),
                  TextField(
                    controller: _locationProvinceController,
                    decoration: InputDecoration(labelText: 'Province'),
                  ),
                  TextField(
                    controller: _contactNameController,
                    decoration:
                        InputDecoration(labelText: 'Contact Person Name'),
                  ),
                  TextField(
                    controller: _contactEmailController,
                    decoration: InputDecoration(labelText: 'Contact Email'),
                  ),
                  TextField(
                    controller: _menuDescriptionController,
                    decoration: InputDecoration(labelText: 'Menu Description'),
                  ),
                  TextField(
                    controller: _foodNameController,
                    decoration: InputDecoration(labelText: 'Food Name'),
                  ),
                  TextField(
                    controller: _foodDescriptionController,
                    decoration: InputDecoration(labelText: 'Food Description'),
                  ),
                  ElevatedButton(
                    onPressed: _addVendor,
                    child: Text('Add Vendor'),
                  ),
                ],
              ),
            ),
            // Updated ListView to be within the Column, avoiding the Expanded widget
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: vendors.isNotEmpty
                  ? ListView.builder(
                      shrinkWrap:
                          true, // Allow ListView to take only required space
                      physics: NeverScrollableScrollPhysics(),
                      itemCount: vendors.length,
                      itemBuilder: (context, index) {
                        final vendor = vendors[index];
                        return Card(
                          child: ListTile(
                            title: Text(vendor['restaurantName']),
                            subtitle: Text(vendor['restaurantDescription']),
                            onTap: () {
                              showDialog(
                                context: context,
                                builder: (context) =>
                                    VendorDetailsDialog(vendor: vendor),
                              );
                            },
                          ),
                        );
                      },
                    )
                  : Center(child: Text('No vendors added yet')),
            ),
          ],
        ),
      ),
    );
  }
}

class VendorDetailsDialog extends StatelessWidget {
  final Map<String, dynamic> vendor;

  VendorDetailsDialog({required this.vendor});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(vendor['restaurantName']),
      content: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Description: ${vendor['restaurantDescription']}'),
            SizedBox(height: 10),
            Text('Location:'),
            Text('  City: ${vendor['location']['city']}'),
            Text('  Province: ${vendor['location']['province']}'),
            SizedBox(height: 10),
            Text('Contact:'),
            Text('  Name: ${vendor['contact']['personName']}'),
            Text('  Email: ${vendor['contact']['Email']}'),
            SizedBox(height: 10),
            Text('Menu: ${vendor['menu']['menuDescription']}'),
            SizedBox(height: 10),
            Text('Food Items:'),
            ...vendor['foodItems'].map<Widget>((foodItem) {
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 5.0),
                child: Text(
                  '${foodItem['foodName']} - ${foodItem['foodDescription']}',
                ),
              );
            }).toList(),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: Text('Close'),
        ),
      ],
    );
  }
}

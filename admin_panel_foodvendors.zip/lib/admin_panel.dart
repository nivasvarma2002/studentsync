import 'package:flutter/material.dart';
import 'food_vendors_admin_page.dart';

class AdminPanel extends StatelessWidget {
  const AdminPanel({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Panel'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          FoodVendorsAdminPage()), // Removed the 'const' here
                );
              },
              child: const Text('Manage Food Vendors'),
            ),
          ],
        ),
      ),
    );
  }
}
